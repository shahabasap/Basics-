function QuickSort(nums){
    if(nums.length <= 1){
        return nums
    }

    let pivot = nums[0]
    let left = []
    let right = []

    for(let i=1;i<nums.length;i++){
        if(nums[i] < pivot){
          left.push(nums[i])
        }else{
            right.push(nums[i])
        }
    }

    return [...QuickSort(left),pivot,...QuickSort(right)]
}

const nums = [8,5,9,3,6,89,3,2]
console.log(QuickSort(nums));