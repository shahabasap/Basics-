function insertionSort(nums){

    for(let i = 1;i<nums.length;i++){
        let NTI = nums[i]
        let j = i -1

        while(j >= 0 && nums[j] > NTI ){
            nums[j+1] = nums[j]
            j--
        }
        nums[j+1] = NTI
    }
    return nums
}

const nums = [8,4,73,5,7,]
console.log(insertionSort(nums))