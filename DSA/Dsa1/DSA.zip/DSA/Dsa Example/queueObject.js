class Queue{
    constructor(){
        this.queue = {}
        this.rear = 0
        this.front = 0
    }

    enqueue(element){
        this.queue[this.rear] = element
        this.rear++
    }

    dequeue(){
        const item = this.queue[this.front]
        delete this.queue[this.front]
        this.front++
        return item
    }
    peek(){
        return this.queue[this.front]
    }
    isEmpty(){
        return this.rear - this.front === 0
    }

    size(){
        return this.rear - this.front
    }

    print(){
        console.log(this.queue);
    }
}

const queue = new Queue()
queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.enqueue(40)
queue.print()
queue.dequeue()
queue.print()
console.log(queue.peek());
console.log(queue.isEmpty());
console.log(queue.size());