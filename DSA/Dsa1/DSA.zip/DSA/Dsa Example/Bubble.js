function BubbleSort(nums){

    let swapped
    do {
        swapped = false
        for(let i=0;i<nums.length;i++){
            if(nums[i] >= nums[i+1]){
                let temp = nums[i]
                nums[i] = nums[i+1]
                nums[i+1] = temp
                swapped = true
            }
        }
    } while (swapped);
}

let nums = [10,30,50,40,29.20]
BubbleSort(nums)
console.log(nums)