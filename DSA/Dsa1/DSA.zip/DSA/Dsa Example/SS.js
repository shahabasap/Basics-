function selectionSort(nums){

    for(let i=0;i<nums.length;i++){
        let min = i
        for(let j=i+1;j<nums.length;j++){
            if(nums[j] < nums[min] ){
                min = j 
            }
        }
        if(min != i){
            let temp = nums[i]
            nums[i] = nums[min]
            nums[min] = temp
        }
    }
    return  nums
}

const nums = [7,3,7,3,7,3,4,7,8,9,3,2]
console.log(selectionSort(nums));