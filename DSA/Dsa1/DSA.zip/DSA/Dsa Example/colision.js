class HashTable{
    constructor(size){
        this.size = size
        this.table = new Array(size)
    }

    hash(key){
        let total = 0
        for(let i=0;i<key.length;i++){
            total += key.charCodeAt(i)
        }
        return total % this.size
    }

    set(key,value){
        const index = this.hash(key)
        // this.table[index] = value

        const bucket = this.table[index]
        if(!bucket){
            this.table[index] = [[key,value]]
        }else{
            const samekeyvalue = bucket.find(item => item[0] === key)
            if(samekeyvalue){
                samekeyvalue[1] = value
            }else{
                bucket.push([key,value])
            }
        }
    }

    get(key){
        const index = this.hash(key)
        // this.table[index]

        const bucket = this.table[index]
        if(bucket){
            const samekeyvalue = bucket.find(item => item[0] === key)
            if(samekeyvalue){
                return samekeyvalue[1]
            }
        }
        return null
    }

    remove(key){
        const index = this.hash(key)
        // this.table[index] = undefined

        const bucket = this.table[index]
        if(bucket){
            const someKeyItem = bucket.find(item => item[0] === key)
            if(someKeyItem){
                bucket.splice(bucket.indexOf(someKeyItem),1)
            }
        }
    }

    display(){
        for(let i=0;i<this.table.length;i++){
            if(this.table[i]){
                console.log(i,this.table[i]);
            }
        }
    }
}

const hash = new HashTable(50)

hash.set("name","KPK")
hash.set("mane","KPK")
hash.set("age",20)
hash.get("name")
hash.display()
hash.remove("age")
hash.display()