// function insertionSort(arr){
//     for(let i=1;i<arr.length;i++){
//         let NTI = arr[i]
//         let j = i - 1

//         while(j >=0 && arr[j] > NTI){
//             arr[j+1] = arr[j]
//             j--
//         }
//         arr[j+1] = NTI
//     }

//     return arr
// }

const arr = [5,3,7,9,2,8]
console.log(insertionSort(arr))

function insertionSort(arr){

    let i = 1

    while( i < arr.length ){
        let NTI = arr[i]
        let j = i - 1

        while(j >= 0 && arr[j] > NTI){
            arr[j+1] = arr[j]
            j--
        }

        arr[j+1] = NTI
        i++
    }

    return arr

}