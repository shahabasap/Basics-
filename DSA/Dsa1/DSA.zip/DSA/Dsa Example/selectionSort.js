function selectionSort(nums){

    for(i = 0;i<nums.length;i++){
        let min = i
        for(let j=1;j<nums.length;j++){
            if(nums[min] > nums[j]){
                min = j
            }
        }
        if(min != j){
            let temp = nums[i]
            nums[i] = nums[min]
            nums[min] = temp
        }
    }
    return nums
}


const nums = [7,3,7,3,7,3,4,7,8,9,3,2]
console.log(selectionSort(nums));