class Node{
    constructor(value){
        this.value = value
        this.next = null
    }
}

class LinkedList{
    constructor(){
        this.head = null
        this.size=0
    }

    prepend(value){
        const node = new Node(value)
        if(!this.head){
            this.head = node
        }else{
            node.next = this.head
            this.head = node
        }
        this.size++
    }
    removeFirst(){
        if(!this.head){
            return null
        }else{
            this.head = this.head.next
            this.size--
        }
    }
    
    isEmpty(){
        return this.size === 0
    }

    getsize(){
        return this.size
    }

    print(){
        let curr = this.head
        let result = []

        while(curr){
            result.push(curr.value)
            curr = curr.next
        }
        console.log(result.join(" -> "));
    }
}

class Stack{
    constructor(){
        this.stack = new LinkedList()
    }

    push(value){
        this.stack.prepend(value)
    }

    pop(){
        this.stack.removeFirst()
    }

    peek(){
            return this.stack.head.value
    }

    getSize(){
        return this.stack.getsize()
    }
    
    isEmpty(){
        return this.stack.isEmpty()
    }

    print(){
        this.stack.print()
    }

}

const stack = new Stack()

console.log(stack.isEmpty())
stack.push(10)
stack.push(20)
stack.push(30)
stack.push(40)
stack.pop()
stack.print()

console.log(stack.peek());
console.log(stack.getSize());
console.log(stack.isEmpty());
