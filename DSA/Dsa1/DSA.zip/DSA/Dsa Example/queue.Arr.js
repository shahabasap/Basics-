class Queue{
    constructor(){
        this.queue = []
    }

    enqueue(value){
        this.queue.push(value)
    }

    dequeue(){
        if(!this.queue.length){
            return null
        }
       return this.queue.shift()
    }

    peek(){
       return this.queue[0]
    }

    isEmpty(){
        return this.queue.length === 0
    }

    size(){
        return this.queue.length
    }

    print(){
        console.log(this.queue);
    }
}

const queue = new Queue()

queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.enqueue(40)
queue.print()
queue.dequeue()
queue.print()
console.log(queue.peek());
console.log(queue.isEmpty());
console.log(queue.size());