class Node{
    constructor(val){
        this.val = val
        this.next = null
    }
}

class linkedList{
    constructor(){
        this.head = null
        this.size = 0
    }
    prepend(val){
        const node = new Node(val)
        if(!this.head){
          this.head = node
        }else{
            node.next = this.head
            this.head = node
        }
        this.size++
    }

    removeFirst(){
        if(!this.head){
            return null
        }else{
            this.head = this.head.next
        }
        this.size--
    }

    isEmpty(){
        return this.size === 0
    }

    GetSize(){
        return this.size
    }

    print(){
        let curr = this.head
        let resullt = []

        while(curr){
            resullt.push(curr.val)
            curr = curr.next
        }
        console.log(resullt.join(" -> "));
    }
}

class Stack {
    constructor(){
        this.stack = new linkedList()
    }

    push(val){
        this.stack.prepend(val)
    }

    pop(){
        return this.stack.removeFirst()
    }
    peek(){
     return  this.stack.head ? this.stack.head.val : null
    }

    isEmpty(){
        return this.stack.isEmpty()
    }

    size(){
        return this.stack.GetSize()
    }
    print(){
        this.stack.print()
    }
}

const stack = new Stack()
stack.push(10)
stack.push(20)
stack.push(30)
stack.push(40)
stack.print()
stack.pop()
stack.pop()
stack.print()
console.log(stack.peek());
console.log(stack.isEmpty());
console.log(stack.size());
