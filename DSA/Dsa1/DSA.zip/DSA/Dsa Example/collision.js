class HashTable{
    constructor(size){
        this.size = size
        this.table = new Array(size)
    }

    hash(key){
        let total = 0
        for(let i=0;i<key.length;i++){
            total += key.charCodeAt(i)
        }
        return total % this.size
    }

    set(key,value){
        const index = this.hash(key)
        // this.table[index] = value

        const Bucket = this.table[index]

        if(!Bucket){
            this.table[index] = [[key,value]]
        }else{
           const someKeyItem = Bucket.find(item => item[0] === key)
           if(someKeyItem){
            someKeyItem[1] = value
           }else{
            Bucket.push([key,value])
           }
        }
    }

    get(key){
        const index = this.hash(key)
        // return this.table[index]

        const Bucket = this.table[index]
        if(Bucket){
            const someKeyItem = Bucket.find(item => item[0] === key)

            if(someKeyItem){
                return someKeyItem[1]
            }
        }
        return undefined
    }

    remove(key){
        const index = this.hash(key)
        // this.table[index] = undefined

        const bucket = this.table[index]

        if(bucket){
            const someKeyItem = bucket.find(item => item[0] === key)

            if(someKeyItem){
                bucket.splice(bucket.indexOf(someKeyItem),1)
            }
        }
    }

    display(){
        for(let i=0;i<this.table.length;i++){
            if(this.table[i]){
                console.log(i,this.table[i])
            }
        }
    }
}

const table = new HashTable(50)

table.set("name","deepak")
table.set("mane","sabeeh")
table.set("age" , 18)
table.display()
console.log(table.get("name"))
table.remove("age")
table.display()