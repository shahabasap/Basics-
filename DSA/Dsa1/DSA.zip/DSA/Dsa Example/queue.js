class Node{
    constructor(value){
        this.value = value
        this.next =null
        this.prev = null
    }
}

class linkedList{
    constructor(){
        this.head = null
        this.tail = null
        this.size = 0
    }

    append(value){
        const node = new Node(value)
        if(!this.head){
            this.head = node
            this.tail = node
        }else{
            node.prev = this.tail
            this.tail.next = node
            this.tail = node
        }
        this.size++
    }
    removeAtFirst(){
        if(!this.head){
            return null
        }else{
            this.head = this.head.next
            this.head.prev = null
        }
        this.size--
    }

    isEmpty(){
        return this.size.length === 0
    }

    getSize(){
        return this.size
    }

    print(){
        let curr =  this.head
        let result = []

        while(curr){
            result.push(curr.value)
            curr = curr.next
        }
        console.log(result.join(" -> "));
    }
}

class Queue{
    constructor(){
        this.queue = new linkedList()

    }

    enqueue(value){
        this.queue.append(value)
    }

    dequeue(){
        return this.queue.removeAtFirst()
    }

    peek(){
        return this.queue.head ? this.queue.head.value : null
    }
    
    isEmpty(){
        return this.queue.isEmpty()
    }

    size(){
        return this.queue.getSize()
    }

    print(){
        return this.queue.print()
    }

}

const queue = new Queue()

queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.enqueue(40)
queue.print()
queue.dequeue()
queue.print()
console.log(queue.peek());
console.log(queue.isEmpty());
console.log(queue.size());