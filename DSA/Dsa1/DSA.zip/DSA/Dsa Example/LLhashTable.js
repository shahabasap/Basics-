class Node{
    constructor(key,value){
        this.key = key
        this.value = value
        this.next = null
}
}
class HashTable{
   constructor(size){
    this.size = size
    this.table = new Array(size)
   }

    hash(key){
       let total = 0
       for(let i=0;i<key.length;i++){
        total += key.charCodeAt(i)
       }
       return total % this.size
    }

   
    set(key,value){
        const node = new Node(key,value)
        const index = this.hash(key)
        if(!this.table[index]){
            this.table[index] = node
        }else{
            let curr = this.table[index]

            while(curr.next){
                if(curr.key === key){
                    curr.value = value
                    return
                }
               curr = curr.next
            }
            if(curr.key === key){
                curr.value = value
            }else{
                curr.next = node
            }
        }
    }
  
    get(key){
        const index = this.hash(key)

        if(!this.table[index]){
            return undefined
        }else{
            let curr = this.table[index]
            while(curr){
                if(curr.key === key){
                    return curr.value
                }
                curr =curr.next
            }
            return undefined
        }
    }

    remove(key){
        const index = this.hash(key)

        if(!this.table[index]){
            return null
        }else{
          let curr = this.table[index]
          let prev = null

          while(curr){
            if(curr.key === key){
                if(prev){
                    prev.next = curr.next
                }else{
                    this.table[index] = curr
                }
                return
            }
            prev = curr
            curr = curr.next
          }
        }
    }
    display(){
        for(let i=0;i<this.table.length;i++){
            let curr = this.table[i]
            while (curr) {
                console.log(i,curr.key,curr.value);
                curr = curr.next
            }
        }
    }

}

const hash = new HashTable(50)
hash.set("name","shahabas")
hash.set("age",18)
hash.display()
console.log(hash.get("name"));
hash.remove("name")
hash.display()