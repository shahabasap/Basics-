function mergeSort(nums){
    if(nums.length <= 1){
        return nums
    }

    let mid = Math.floor(nums.length / 2)
    let left = nums.slice(0,mid)
    let right = nums.slice(mid)

    return merge(mergeSort(left),mergeSort(right))
}

function merge(left,right){
let sorted = []
    while(left.length && right.length){
        if(left < right){
            sorted.push(left.shift())
        }else{
            sorted.push(right.shift())
        }
    }
    return [...sorted,...left,...right]
}

let arr = [ 38, 27, 43, 10]
console.log(mergeSort(arr));