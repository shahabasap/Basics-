let arr = [2,4,5,6,9]
console.log(BubbleSort(arr))

function BubbleSort(arr){
    let swapped
    do {
        swapped = false
        for(i=0;i<arr.length;i++){
            if(arr[i+1] < arr[i] ){
                let temp = arr[i]
                arr[i] = arr[i+1]
                arr[i+1] = temp
                swapped =true
            }
        }
    } while (swapped);
    return arr;
}