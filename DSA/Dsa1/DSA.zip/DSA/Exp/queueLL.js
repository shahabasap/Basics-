class Node{
    constructor(value){
        this.value =value
        this.next = null
    }
}

class linkedlist{
    constructor(){
        this.head = null
        this.tail = null
        this.size = 0
    }

    append(value){
        const node = new Node(value)
        if(!this.head){
            this.head = node
            this.tail = node
        }else{
            node.next = this.head
            this.head =node
        }
        this.size++
    }

    removeFromFirst(){
        if(!this.head){
            return null
        }else{
            this.head = this.head.next
        }
        this.size++
    }

    isEmpty(){
        return this.size === 0
    }

    getSize(){
        return this.size
    }

    print(){
        let curr = this.head
        let result = []

        while(curr){
            result.push(curr.value)
            curr = curr.next
        }
        console.log(result.join(" -> "));
    }
}

class Queue{
    constructor(){
       this.queue = new linkedlist()
    }
        enqueue(value){
           this.queue.append(value)
        }

        dequeue(){
            return this.queue.removeFromFirst()
        }

        peek(){
           return this.queue.head ? this.queue.head.value : null 
        }

       isEmpty(){
        return this.queue.isEmpty()
       }

       size(){
        return this.queue.getSize()
       }

       print(){
        return this.queue.print()
       }
    }

    const queue = new Queue()

    queue.enqueue(10)
    queue.enqueue(20)
    queue.enqueue(30)
    queue.enqueue(40)
    queue.print()
    queue.dequeue()
    queue.print()
    console.log(queue.peek());
    console.log(queue.isEmpty())
    console.log(queue.size());
