function insertionSort(nums){

    for(let i=0;i<nums.length;i++){
        let NTI = nums[i]
        let j = i-1

        while (j >= 0 && nums[j] > NTI) {
            nums[j+1] = nums[j]
            j--
        }
        nums[j+1] = NTI
    }
    return nums
}

const nums = [9,7,6,3,4,5,6,1,0]

console.log(insertionSort(nums));