function mergeSort(nums){

    if(nums.length <= 1){
     return nums
    }
let mid = Math.floor(nums.length / 2)
let left=nums.slice(0,mid)
let right =  nums.slice(mid)

return merge(mergeSort(left),mergeSort(right))
}

function merge(left,right){
let sorted = []

while(left.length && right.length){
    if(left[0] >= right[0]){
        sorted.push(right.shift())
    }else{
        sorted.push(left.shift())
    }
}
return [...sorted,...left,...right]
}

const nums = [8,6,8,0,5,6,3]
console.log(mergeSort(nums))