class Queue{
    constructor(){
        this.queue = []
    }

    enqueue(value){
        this.queue.push(value)
    }

    dequeue(){
        if(!this.queue){
            return null
        }else{
            return this.queue.shift()
        }
    }

    peek(){
       return this.queue[0]
    }

    isEmpty(){
        return this.queue.length === 0
    }

    getSize(){
        return this.queue.length
    }

    print(){
        console.log(this.queue);
    }
}

const queue = new Queue()

queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.enqueue(40)
queue.enqueue(50)
queue.print()
queue.dequeue()
queue.dequeue()
queue.print()
console.log(queue.peek());
console.log(queue.isEmpty())
console.log(queue.getSize())