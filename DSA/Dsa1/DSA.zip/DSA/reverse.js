// const name  = "John Cena"
// console.log(Reverse(name));

// function Reverse(name){
//     if(name.length <= 1){
//         return name
//     }
//     return Reverse(name.slice(1))+name[0]
// }

// const str = "Navya T Jacob"
// const word = str.split(' ')
// let res=''
// for(let i=0;i<word.length;i++){
//     res=res+" "+swapping(word[i])
// }
// console.log(res)

// function swapping(str){
//     if(!str.length){
//         return ""
//     }
//     return swapping(str.slice(1))+str[0]+""
//  }

// const str = "Krishna Prasad"
// const word = str.split(' ')
// let result = ""

// for(let i=0;i<word.length;i++){
//  result = result+ " "+swapping(word[i])
// }
// console.log(result);

// function swapping(str){
//     if(!str.length){
//         return ""
//     }
//     return swapping(str.slice(1))+str[0]+""
// }