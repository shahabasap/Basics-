function insertionSort(arr){
    for(let i=1;i<arr.length;i++){
       let NTI = arr[i]
       let j = i - 1

       while( j >= 0 && arr[j] > NTI ){
        arr[j+1 ] = arr[j]
        j--
       }
       arr[j+1] = NTI
    }
    return arr
}


const nums = [6,5,8,9,4,3,2,8,7,6,1]
console.log(insertionSort(nums));