function mostRepeated(arr){
let map = new Map()

for(let elem of arr){
    let count = map.get(elem)|| 0
    map.set(elem,count+1)
}

let mostRepeated 
let maxCount = 0

for(let [num,count] of map){

    if(count > maxCount){
        maxCount = count
        mostRepeated = num
    }
  
}
return mostRepeated
}

const arr = [1,1,2,2,3,3,4,4,4,4]
console.log(mostRepeated(arr));