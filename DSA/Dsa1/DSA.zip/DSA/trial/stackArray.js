class Stack{
    constructor(){
        this.item = []
    }

    push(value){
        this.item.push(value)
    }

    pop(){
        if(this.isEmpty()){
            return null
        }else{
           return  this.item.pop()
        }
    }

    peek(){
        if(this.isEmpty()){
            return null
        }else{
          return  this.item[this.item.length-1]
        }
    }

    isEmpty(){
        return this.item.length === 0
    }

    getSize(){
        return this.item.length
    }

    print(){
        console.log(this.item.toString())
    }
}

const stack = new Stack()
stack.push(10)
stack.push(20)
stack.push(30)
stack.push(40)
stack.push(50)
stack.print()
stack.pop()
stack.pop()
stack.print()
console.log(stack.peek());
console.log(stack.getSize());