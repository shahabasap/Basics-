function reverseStr(str){
    let stack = []
    let reverse = ' '

    for(let i=0;i<str.length;i++){
        if(str[i] !== " "){
            stack.push(str[i])
        }else{
            while(stack.length >0){
                reverse += stack.pop()
            }
            reverse += " "
        }
    }
    while(stack.length >0){
        reverse += stack.pop()
    }
    return reverse
}
const str = "krishna prasad";
console.log(reverseStr(str));
