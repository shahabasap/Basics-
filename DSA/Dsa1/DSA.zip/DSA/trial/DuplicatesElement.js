function Duplicates(arr){

    let c = 1
    let map = new Map()

    for(let elem of arr){
            let count = map.get(elem)||0
            map.set(elem,count+1)
    }

    for(let [num,count] of map){

        if(map.get(num) > c){
            return [num,"number of count" ,map.get(num)]
        }
    }
    return true
}

const arr = [1,2,3,1]
console.log(Duplicates(arr));