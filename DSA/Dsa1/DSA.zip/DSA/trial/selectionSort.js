function selectionSort(arr){
    for(i=0;i<arr.length;i++){
        let min = i
        for(j=i+1;j<arr.length;j++){
          if(arr[min] > arr[j]){
            min = j
          }
        }
        if(min != i){
            let temp = arr[i]
            arr[i] = arr[min]
            arr[min] = temp
        }
    }
    return arr
}

const nums = [6,5,8,9,4,3,2,8,7,6,1]
console.log(selectionSort(nums));