class Queue{
constructor(){
    this.item = []
}

enqueue(value){
    this.item.push(value)
}

dequeue(){
    return this.item.shift()
}

peek(){
    return this.item[0]
}

isEmpty(){
   return this.item.length === 0
}
getSize(){
    return this.item.length
}

print(){
    console.log(this.item);
}
}

const queue = new Queue()

queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.print()
queue.dequeue()
console.log(queue.peek());
console.log(queue.isEmpty());


