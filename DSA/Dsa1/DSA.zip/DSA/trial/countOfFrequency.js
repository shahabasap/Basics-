function frequencyCount(arr){
    let map = new Map()

    for(let elem of arr){
        let count = map.get(elem) || 0
        map.set(elem,count+1)
    }
    return map
}

const arr = [1,2,2,3,3,3,4,4,4]
console.log(frequencyCount(arr));