// function QuickSort(arr){
//     if(arr.length <= 1){
//         return arr
//     }

//     let pivot = arr[0]
//     let left = []
//     let right = []

//     for(let i=1;i<arr.length;i++){
//         if(arr[i] < pivot){
//             left.push(arr[i])
//         }else{
//             right.push(arr[i])
//         }
//     }
//     return [...QuickSort(left),pivot,...QuickSort(right)]
// }

// const arr = [1,5,6,9,8,7,3,4,0]
// console.log(QuickSort(arr));


function QuickSort(arr, start = 0, end = arr.length - 1) {
    if (start >= end) {
        return;
    }

    let pivotIndex = partition(arr, start, end);
    QuickSort(arr, start, pivotIndex - 1);
    QuickSort(arr, pivotIndex + 1, end);
    return arr;
}

function partition(arr, start, end) {
    let pivot = arr[end];
    let pivotIndex = start;

    for (let i = start; i < end; i++) {
        if (arr[i] < pivot) {
            [arr[i], arr[pivotIndex]] = [arr[pivotIndex], arr[i]];
            pivotIndex++;
        }
    }
    [arr[pivotIndex], arr[end]] = [arr[end], arr[pivotIndex]];
    return pivotIndex;
}

const arr = [1, 5, 6, 9, 8, 7, 3, 4, 0];
console.log(QuickSort(arr));
