function twoSum(arr,target){
let map = new Map()

for(let i=0;i<arr.length;i++){
    let compeleted = target - arr[i]
    if(map.has(compeleted)){
        return [compeleted,arr[i]]
    }
    map.set(arr[i],i)
}
return null
}

const arr = [5,2,3,7] , target = 9

console.log(twoSum(arr,target));